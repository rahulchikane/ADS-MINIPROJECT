import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class BestInternetServiceProviderMain
{
     public static void main(String[] args)
     {
          Scanner sc=new Scanner(System.in);
    int n;
    Queue1 q=new Queue1();
        do{
            
            System.out.println("Enter 1 For Registration");
            System.out.println("Enter 2 For Genrating Ticket"); 
            System.out.println("0=EXIT");
            n=sc.nextInt();
            switch(n)
            {
                case 1 :
         ArrayList<String> isp = new ArrayList<String>();

         isp.add("BSNL");
         isp.add("Hathway");
         isp.add("GigaByte");
         isp.add("AirtelFiber");
         isp.add("JioFiber"); 
         isp.add("StarLink");
         isp.add("Eyxn");
         isp.add("Joister");
         isp.add("MagmaLink");
         isp.add("Ethernet");
   
         Collections.sort(isp);    // sorting internet service providers
          System.out.println("Service Provider");
           System.out.println();
         for(String i : isp)
         {
            System.out.println(i);
         }
          System.out.println();
           System.out.println("=====================");
         
         ConcurrentHashMap<Integer, String> bi = new ConcurrentHashMap<Integer, String>();

         bi.put(01, "Airtel Fiber");
         bi.put(02, "BSNL");
         bi.put(03, "Ethernet");
         bi.put(04, "Eyxn");
         bi.put(05, "GigaByte");
         bi.put(06, "Hathway");
         bi.put(07, "Jio Fiber");
   
 //System.out.println("\n" + bi); 
 
         bi.remove(05, "GigaByte");          // Removing the entries for ISP05,ISP06,ISP07
         bi.remove(06, "Hathway");
         bi.remove(07, "Jio Fiber");
     
         
         bi.replace(01, "Airtel Fiber", "Jio Fiber");     // Replacing the values for keys ISP01,ISP02,ISP03,ISP04
         bi.replace(02, "BSNL", "Airtel Fiber");
         bi.replace(03, "Ethernet", "Hathway");
         bi.replace(04, "Eyxn", "GigaByte");
         
         System.out.println("The Best Internet Service Providers In Your City ");
         System.out.println("\n" + bi);      // Printing the ConcurrentHashMap List
            System.out.println("=====================");
         
          Broadband bsp = new Broadband();
          CalculateAmt ca = new CalculateAmt();
          System.out.println(" \nThe Broadband Packages of Best Internet Service Providers In Your City ");

          bsp.main1();
          bsp.firstDetails1();
          bsp.secondDetails1();

          bsp.main2();
          bsp.firstDetails2();
          bsp.secondDetails2();

          Scanner s = new Scanner(System.in);
          
          System.out.println("Welcome for Registration of Broadband Connection");
          bsp.info();
         // bsp.registrationDetails();
          bsp.packageChoice();

          System.out.println("Please Select Your Package:\n1. Main1\n2. Main2");
          int p = s.nextInt();
          if(p == 1)
            bsp.main1();
          else if(p == 2)
            bsp.main2();
          else
            System.out.println("Invalid Choice!!");
          
          int x;
          char a;
          do{
            System.out.println("Please Enter Your Choice:\n1. First Details1\n2. Second Details1\n3. First Details2\n4. Second Details2");
            x = s.nextInt();
            switch(x)
            {
     /*
                case 1:
                    bsp.registrationDetails();
                    break;
                case 2:
                    bsp.packageChoice();
                    break;
                case 3:
                    bsp.main1();
                    break;  */ 
                case 1:
                    //bsp.registrationDetails();
                    bsp.firstDetails1();
                    System.out.println("\t\t\t\t\t\t\tBill Payment\t\t\t\t\t\t\t\n");
    ca.index();
    //int n;
    char b;
    do{
         System.out.println("Please enter Package: \n1. Choice1\n2. Choice2\n3. Choice3\n4. Choice4");
         n = s.nextInt();
         
         switch(n)
         {
               case 1:
                   bsp.registrationDetails();
                      ca.choice1();
                      break;

               case 2:
                   bsp.registrationDetails();
                      ca.choice2();
                      break;

               case 3:
                   bsp.registrationDetails();
                      ca.choice3();
                      break;

               case 4:
                   bsp.registrationDetails();
                      ca.choice4();
                      break;

              default:
                      System.out.println("You have entered wrong choice");
         }
          System.out.println("\nPress 'Y' to CONTINUE or 'N' to EXIT.\n");
          a = s.next().charAt(0);
      }while(a != 'N');
           System.out.println("Thank You For Registration with us!!!!");     
                    break;
                case 2:
                    //bsp.registrationDetails();
                    bsp.secondDetails1();
                      System.out.println("\t\t\t\t\t\t\tBill Payment\t\t\t\t\t\t\t\n");
    ca.index();
    
    do{
         System.out.println("Please enter Package: \n1. Choice1\n2. Choice2\n3. Choice3\n4. Choice4");
         n = s.nextInt();
         
         switch(n)
         {
               case 1:
                   bsp.registrationDetails();
                      ca.choice1();
                      break;

               case 2:
                   bsp.registrationDetails();
                      ca.choice2();
                      break;

               case 3:
                   bsp.registrationDetails();
                      ca.choice3();
                      break;

               case 4:
                   bsp.registrationDetails();
                      ca.choice4();
                      break;

              default:
                      System.out.println("You have entered wrong choice");
         }
          System.out.println("\nPress 'Y' to CONTINUE or 'N' to EXIT.\n");
          a = s.next().charAt(0);
      }while(a != 'N');
           System.out.println("Thank You For Registration with us!!!!");   
                    break;
     /*
                case 6:
                    bsp.main2();
                    break;   */
                case 3:
                    //bsp.registrationDetails();
                      System.out.println("\t\t\t\t\t\t\tBill Payment\t\t\t\t\t\t\t\n");
    ca.index();
    
    do{
         System.out.println("Please enter Package: \n1. Choice1\n2. Choice2\n3. Choice3\n4. Choice4");
         n = s.nextInt();
         
         switch(n)
         {
               case 1:
                   bsp.registrationDetails();
                      ca.choice1();
                      break;

               case 2:
                   bsp.registrationDetails();
                      ca.choice2();
                      break;

               case 3:
                   bsp.registrationDetails();
                      ca.choice3();
                      break;

               case 4:
                   bsp.registrationDetails();
                      ca.choice4();
                      break;

              default:
                      System.out.println("You have entered wrong choice");
         }
          System.out.println("\nPress 'Y' to CONTINUE or 'N' to EXIT.\n");
          a = s.next().charAt(0);
      }while(a != 'N');
           System.out.println("Thank You For Registration with us!!!!");   
                    bsp.firstDetails2();
                    break; 
                case 4:
                   // bsp.registrationDetails();
                      System.out.println("\t\t\t\t\t\t\tBill Payment\t\t\t\t\t\t\t\n");
    ca.index();
    
    do{
         System.out.println("Please enter Package: \n1. Choice1\n2. Choice2\n3. Choice3\n4. Choice4");
         n = s.nextInt();
         
         switch(n)
         {
               case 1:
                   bsp.registrationDetails();
                      ca.choice1();
                      break;

               case 2:
                   bsp.registrationDetails();
                      ca.choice2();
                      break;

               case 3:
                   bsp.registrationDetails();
                      ca.choice3();
                      break;

               case 4:
                   bsp.registrationDetails();
                      ca.choice4();
                      break;

              default:
                      System.out.println("You have entered wrong choice");
         }
          System.out.println("\nPress 'Y' to CONTINUE or 'N' to EXIT.\n");
          a = s.next().charAt(0);
      }while(a != 'N');
           System.out.println("Thank You For Registration with us!!!!");   
                    bsp.secondDetails2();
                    break;
                default:
                    System.out.println("Invalid choice!");
                    break;
            }
         System.out.println("\nPress 'Y' to CONTINUE or 'N' to EXIT.\n");
         a = s.next().charAt(0);
            }while(a != 'N');
             //System.out.println("Thank You for Visiting");
             break;
             
             
     
     case 2:
                    //Queue1 q=new Queue1();
        //int n;
        do
        {
            System.out.println("Enter your UserId (Phone Number)");
            System.out.println("1=enque  2=deque  3=status  0=EXIT");
            n=sc.nextInt();
            switch(n)
            {
                case 1:
                    n=sc.nextInt();
                    q.enque(n);
                    break;
                case 2:
                    q.deque();
                    break;
                case 3:
                    q.status();
                    break;
            }
        }while(n!=0);
        System.out.println("EXIT");
        
        System.out.println("Enter The Issue 1.Link down or 2.Speed Issue");
        String issue=sc.next();
        System.out.println("Dear Customer,  Kindly note that a trouble ticket has been booked regarding " +issue+ " and assigned\n" +
"to the concerned team for investigation.");
            
}
}while(n!=0);
        System.out.println("Exit");
 }
}