import java.util.Scanner;
import java.time.LocalDateTime;

class Broadband
{ 
       String name1 = "Jio Fiber";

       String name2 = "Airtel Fiber";

       private String pc;
       private int in;
       private String cn;
       private int uid;
       private int pn;
       private String add;
 
       Scanner sc = new Scanner(System.in);
         
         void main1()
         {    
             System.out.println("\nISP: " +name1);         
             System.out.print("Package No.");
             System.out.print("      Speed");
             System.out.print("            Duration");
             System.out.println("                        Price");
         }
     
          void firstDetails1()
         {
             int num1 = 1;
             int sp1 = 20;             
             int d1 = 6;             
             double p1 = 4500.00;
                                  
             System.out.print("\nPackageNo: " +num1);
             System.out.print("     "+sp1);
             System.out.print(" MBPS");
             System.out.print("          "+d1);
             System.out.print(" Months");
             System.out.print("                        "+p1);
             System.out.println(" Rs/-");
         }

         void secondDetails1()
         {
             int num2 = 2;
             int sp2 = 50;             
             int d2 = 12;             
             double p2 = 8500.00;
                     
             System.out.print("\nPackageNo: " +num2);
             System.out.print("     "+sp2);
             System.out.print(" MBPS");
             System.out.print("          "+d2);
             System.out.print(" Months");
             System.out.print("                       "+p2);
             System.out.println(" Rs/-");
             System.out.println("\n=========================================");
         }

         void main2()
         {    
             System.out.println("\nISP: " +name2);         
             System.out.print("Package No.");
             System.out.print("      Speed");
             System.out.print("            Duration");
             System.out.println("                        Price");
         }
     
          void firstDetails2()
         {
             int num1 = 1;
             int sp1 = 20;             
             int d1 = 6;             
             double p1 = 5000.00;
                                  
             System.out.print("\nPackageNo: " +num1);
             System.out.print("     "+sp1);
             System.out.print(" MBPS");
             System.out.print("          "+d1);
             System.out.print(" Months");
             System.out.print("                        "+p1);
             System.out.println(" Rs/-");
         }

         void secondDetails2()
         {
             int num2 = 2;
             int sp2 = 50;             
             int d2 = 12;             
             double p2 = 9500.00;
                     
             System.out.print("\nPackageNo: " +num2);
             System.out.print("     "+sp2);
             System.out.print(" MBPS");
             System.out.print("          "+d2);
             System.out.print(" Months");
             System.out.print("                       "+p2);
             System.out.println(" Rs/-");
         }

         void info()
    {
        System.out.println("Customer Name: ");
        cn = sc.nextLine();

        System.out.println("User_ID: ");
        uid = sc.nextInt();

        System.out.println("Phone Number : ");
        pn = sc.nextInt();

        System.out.println("Address: ");
        add = sc.next();
