import java.util.Scanner;
class CalculateAmt
{
   //String pc1, pc2, pc3, pc4;
    String pc1 = "Package01";
    String pc2 = "Package02";
    String pc3 = "Package03";
    String pc4 = "Package04";

   //double pr1, pr2, p3, p4;
    double pr1 = 4500;
    double pr2 = 8500;
    double pr3 = 5000;
    double pr4 = 9500;

    //double g1, g2, g3, g4;
    double gt = 0.18;
    double g1 = gt*pr1;
    double g2 = gt*pr2;
    double g3 = gt*pr3;
    double g4 = gt*pr4;
    

    //double ta1, ta2, ta3, ta4;
    double ta1 = pr1 + g1;
    double ta2 = pr2 + g2;
    double ta3 = pr3 + g3;
    double ta4 = pr4 + g4;

    void index()
    {
        System.out.println("\t\t\tPackage\t\t\t\t\tAmount\n");  
    }
    
    void choice1()
    {
        System.out.println("\t\t\t"+pc1+ "\t\t\t\t"+pr1);
        System.out.println("\n\t\t\t+18% GST:\t\t\t\t"+g1);
        System.out.print("Rs./-");
        System.out.println("=================================================================");
        System.out.println("\n\t\t\tTotal Amount:\t\t\t\t"+ta1);
        System.out.print("Rs./-");
    }
    void choice2()
    {
        System.out.println("\t\t\t"+pc2+ "\t\t\t\t"+pr2);
        System.out.println("\n\t\t\t+18% GST:\t\t\t\t"+g2);
        System.out.print("Rs./-");
        System.out.println("=================================================================");
        System.out.println("\n\t\t\tTotal Amount:\t\t\t\t"+ta2);
        System.out.print("Rs./-");
    }
    void choice3()
    {
        System.out.println("\t\t\t"+pc3+ "\t\t\t\t"+pr3);
        System.out.println("\n\t\t\t+18% GST:\t\t\t\t"+g3);
        System.out.print("Rs./-");
        System.out.println("=================================================================");
        System.out.println("\n\t\t\tTotal Amount:\t\t\t\t"+ta3);
        System.out.print("Rs./-");
    }
    void choice4()
    {
        System.out.println("\t\t\t"+pc4+ "\t\t\t\t"+pr4);
        System.out.println("\n\t\t\t+18% GST:\t\t\t\t"+g4);
        System.out.print("Rs./-");
        System.out.println("=================================================================");
        System.out.println("\n\t\t\tTotal Amount:\t\t\t\t"+ta4);
        System.out.print("Rs./-");
    }

}