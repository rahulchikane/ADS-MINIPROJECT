import java.util.*;
class Queue1
{
   // int capacity=5;
    int size=0;
    int front =-1;
    int rear =-1;
    int arr[]=new int[5];
    void enque(int x)
    {
        if(size==5)
        {
            System.out.println("full");
        }
        else
         if(front>=0 && rear==4 )
        {
           // front=-1;
            rear=-1;
            arr[++rear]=x;
            size++;
            System.out.println("push"+arr[rear]+"index="+rear);
        }else   
        {
        arr[++rear]=x;
        size++;
        System.out.println("push"+arr[rear]+"index="+rear);
        }
        
    }
    void deque()
    {
        if(size==0)
        {
            System.out.println("empty");
        }else
        if(front==4)
        {
            front=-1;
            front++;
            System.out.println("pop"+arr[front]+"index="+front);
            
            size--;
        }else    
        {
            front++;
            System.out.println("pop"+arr[front]+"index="+front);
            size--;
        }
    }
    void status()
    {
        System.out.println("rearIndex="+rear+"  frontIndex="+front);
        if(size==5)
        {
            System.out.println("queue is full");
        }
        if(size==0)
        {
            System.out.println("queue is empty");
        }
        if((size!=0) && (size!=5))
        {
            System.out.println("you can add value or remove value");
        }
    }
}